---
# yaml-language-server: $schema=schemas/concept.schema.json
Object type:
    - Concept
Backlinks:
    - section-12-resolution-of-theoretical-contradic.md
    - d-w-winnicott.md
    - aba-design-withdrawal-phase.md
    - 5-journal-time-as-schema-consolidation-the-per.md
Status: In Progress
Creation date: "2025-11-22T11:53:06Z"
Created by:
    - Roi Ezra
Links:
    - journal.md
    - d-w-winnicott.md
id: bafyreifs4eshqvy4sktkwssxmafwpjhbyxreqzibiszjc5cv3e5sq4xj4y
---
# Surviving Object   
The object that is "destroyed" (attacked/used intensely) but does not retaliate, proving its reality   
[Journal](journal.md)    
[D.W. Winnicott](d-w-winnicott.md)    
