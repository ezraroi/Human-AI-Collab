---
# yaml-language-server: $schema=schemas/task.schema.json
Object type:
    - Task
Assignee:
    - Roi Ezra
Due date: "2025-11-23"
Status: Pending
Creation date: "2025-11-23T07:10:50Z"
Created by:
    - Roi Ezra
Links:
    - Roi Ezra
id: bafyreif56e53mklkja2mgz4hg7ahyi2kvtqjsj3qf2kywx7pxjwhzlx4xi
---
# Learn on Bion Selected Fact   
## Details    
 --- 
Need to learn on Bion Selected Fact in shortly and update the object   
   
   
