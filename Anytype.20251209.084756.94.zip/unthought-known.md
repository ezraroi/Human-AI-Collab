---
# yaml-language-server: $schema=schemas/concept.schema.json
Object type:
    - Concept
Backlinks:
    - christopher-bollas.md
Status: In Progress
Creation date: "2025-11-23T06:43:29Z"
Created by:
    - Roi Ezra
Emoji: "\U0001F4A1"
id: bafyreiegty5vr6uwikxzrs2ku25xaknrblg3oygpvtudzjckysugfc5whm
---
# Unthought Known   
