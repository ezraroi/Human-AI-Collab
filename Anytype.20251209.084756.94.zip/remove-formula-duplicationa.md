---
# yaml-language-server: $schema=schemas/task.schema.json
Object type:
    - Task
Due date: "2025-11-24"
Creation date: "2025-11-24T19:11:53Z"
Created by:
    - Roi Ezra
id: bafyreidyyj2n23bmkckqbpr4nzuiotfp6maxwxjczzfhu5au3fngay7qsi
---
# remove formula duplicationa   
## Details    
 --- 
based on NoteBookLM answer and anytype   
   
   
