---
# yaml-language-server: $schema=schemas/note.schema.json
Object type:
    - Note
Creation date: "2025-11-22T21:09:47Z"
Created by:
    - Roi Ezra
id: bafyreids2kjprsxnk4bdy5rafnqs3lq6ha3xqgzcvnaeniyl4td3ipvoeu
---
מנגנון הכנת קונטקס לכל המאמרים והספר.   
מחברת חכמה דיגטלית שאני עורך עם AI ערכים ומכין לכל שיחה את הקונטקס המדויק   
לחשוב על מנגנון סיכום התוכן לאובייקטים מרכזים בעזרת AI   
   
